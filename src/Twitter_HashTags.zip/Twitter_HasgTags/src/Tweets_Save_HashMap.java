import java.util.HashMap;
import java.util.Iterator;
import java.util.Comparator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.Map;
import java.util.Map.Entry;

import twitter4j.*;
import twitter4j.conf.ConfigurationBuilder;

public class Tweets_Save_HashMap {
	int input;
	int No_Of_HashTags_Print;
	List<HashtagEntity[]> Hashtag;
	public Tweets_Save_HashMap(int HashTagCount,int TopTags) {
		// TODO Auto-generated constructor stub
		input = HashTagCount;
		No_Of_HashTags_Print = TopTags;
	}
	
	
	int index=0;
	static int arraycount =0;
 	public void run(){
 		
	ConfigurationBuilder conf = new ConfigurationBuilder();
	conf.setDebugEnabled(true)
    .setOAuthConsumerKey("")
    .setOAuthConsumerSecret("")
    .setOAuthAccessToken("")
    .setOAuthAccessTokenSecret("");
	
	Hashtag = new ArrayList<HashtagEntity[]>();
    final TwitterStream twitterStream = new TwitterStreamFactory(conf.build()).getInstance();
    StatusListener listener = new StatusListener() {
        @Override
        public void onStatus(Status status) {
            
        	HashtagEntity[] tokencheck;
        	
           tokencheck = status.getHashtagEntities();
           
        
               
        	   
        	   if(arraycount==input)
        	   { 
        		   new HashMap_Sort_Print(Hashtag,No_Of_HashTags_Print,input).run();
        	   } else {
        		   arraycount++;
        	   }
        	  
        	
        	   if(index>=input){
        		   Hashtag.set(index%input, tokencheck);
        	   }
        	   else
        	   {
        	   Hashtag.add(index%input, tokencheck);
        	   
        	   }
        	   index++;
        	      	   
           
              
        }
        
     
		@Override
		public void onException(Exception arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onDeletionNotice(StatusDeletionNotice arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onScrubGeo(long arg0, long arg1) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onStallWarning(StallWarning arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onTrackLimitationNotice(int arg0) {
			// TODO Auto-generated method stub
			
		}

    };


    

twitterStream.addListener(listener);
twitterStream.sample();
}

	
}
