import java.io.FileReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import twitter4j.HashtagEntity;


public class HashMap_Sort_Print {
	
	List<HashtagEntity[]> HashTag_Map;
	int Print_Tags_Number;
	int slidingwindowcount;
	public HashMap_Sort_Print(List<HashtagEntity[]> hashTag,int Print_Tags_Number_Input,int slidingwindowcount1) {
		HashTag_Map=hashTag;
		Print_Tags_Number=Print_Tags_Number_Input;
		slidingwindowcount = slidingwindowcount1;
				// TODO Auto-generated constructor stub
	}

	
	public void run() {
		// TODO Auto-generated method stub
		 Map<String, Integer> twitter_hashtag = new HashMap<String, Integer>();
		for(HashtagEntity[] tags : HashTag_Map)
		{
			for (HashtagEntity e : tags) {
				if (twitter_hashtag.containsKey(e.getText())) {
					twitter_hashtag.put(e.getText(),
							twitter_hashtag.get(e.getText()) + 1);
				} else {
					twitter_hashtag.put(e.getText(), 1);
				}
			}
		}
			
		List<Entry<String, Integer>> list = new ArrayList<Entry<String, Integer>>(twitter_hashtag.entrySet());
     	Collections.sort( list, new Comparator<Map.Entry<String, Integer>>()
     	{
     		public int compare( Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2 ){
     		return (o2.getValue()).compareTo( o1.getValue() );
     	}
 } );
     	
     	hashtagprint(list);
     	
	}
	
	void hashtagprint(List<Entry<String, Integer>> list){
		for(int i=0;i<Print_Tags_Number;i++){
		
        System.out.println("HashTag is : #"+list.get(i).getKey()+"     *********     "+" its count in the window is : "+list.get(i).getValue());
        }
		System.out.println();
		System.out.println();
		System.out.println("++++++++++++Hashtags in the window are displayed+++++++++++++++++++");
		System.out.println();
		System.out.println();
    	}
}
