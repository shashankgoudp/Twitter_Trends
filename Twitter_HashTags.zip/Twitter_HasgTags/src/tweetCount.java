import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Scanner;

public class tweetCount {

    public static void main(String args[]) {
    	tweetCount countCompetition = new tweetCount();
    	System.out.println("Enter the SlidingWindow Size:");
    	String slidingwindowcount;
    	 
        Scanner scanIn = new Scanner(System.in);
        slidingwindowcount = scanIn.nextLine();
        
        System.out.println("Enter the number of HashTags:");
        
        String Top_Hash_Count;
        Top_Hash_Count = scanIn.nextLine();
        scanIn.close();            
    	
    	   	
    	int input_sliding_windowcount = Integer.parseInt(slidingwindowcount);
    	int input_Top_Hash_Count = Integer.parseInt(Top_Hash_Count);
        try {
			countCompetition.run(input_sliding_windowcount,input_Top_Hash_Count);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    public void run(int input_sliding_windowcount,int input_Top_Hash_Count) throws InterruptedException {
    int input_sliding_windowcount1 = input_sliding_windowcount;
    int input_Top_Hash_Count1= input_Top_Hash_Count;
		
        new Tweets_Save_HashMap(input_sliding_windowcount1,input_Top_Hash_Count1).run();
       
    }

 
}